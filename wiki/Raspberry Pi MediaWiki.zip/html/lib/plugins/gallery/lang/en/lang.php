<?php

$lang['pages'] = 'Gallery Pages:';
$lang['js']['addgal'] = 'Add namespace as gallery';
$lang['nothingfound'] = 'No images found.';
