<?php

$lang['translations'] = 'Translations of this page';
$lang['outdated']     = 'This translation is older than the <a href="%s" class="wikilink1">original page</a> and might be outdated.';
$lang['diff']         = 'See what has <a href="%s" class="wikilink1">changed</a>.';
$lang['transloaded']  = 'The contents of this page\'s translation in %s have been pre-loaded for easy translation.<br />But you can base your translation on the following existing translations: %s.';
$lang['menu'] = "outdated and missing translations";
$lang['missing']      = 'Missing!';
$lang['old']          = 'outdated';
$lang['current']      = 'up-to-date';
$lang['path']         = 'Path';
